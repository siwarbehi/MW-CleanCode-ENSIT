# MW-CleanCode-ENSIT
This repository for ENSIT Second year students to apply what they learned about Clean Code.
Each students need:
* To clone the project.
* Create a branche with his name.
* Make changes to the "Bad" code to make it "Good" code.
* Push it to his branch.
